## Variant for serverless function 

The entry is `main_handler`, and these two dependencies `requests` and `beautifulsoup4` need to be packaged (Compress into .zip file) together with the source code `main.py`, then deploy.

