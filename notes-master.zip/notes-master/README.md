## Azure 提取 API

```shell
wget -N https://raw.githubusercontents.com/Misaka-blog/notes/master/azapi.sh && bash azapi.sh
```

## Hax Ubuntu 20.04 更新过慢问题

```shell
wget -N https://raw.githubusercontents.com/Misaka-blog/notes/master/haxu20.sh && bash haxu20.sh
```
