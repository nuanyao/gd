# TUN 模块开启脚本

在OpenVZ机器上无需使用面板干预开启TUN模块

已集成至：https://github.com/Misaka-blog/Misaka-WARP-Script

如对脚本不放心，可使用此沙箱先测一遍再使用：https://killercoda.com/playgrounds/scenario/ubuntu

## 使用方法

```shell
wget -N --no-check-certificate https://raw.githubusercontents.com/Misaka-blog/tun-script/master/tun.sh && bash tun.sh
```

## 交流群

[Telegram](https://t.me/misakanetcn)

## 赞助我们

![afdian-MisakaNo.jpg](https://s2.loli.net/2021/12/25/SimocqwhVg89NQJ.jpg)
