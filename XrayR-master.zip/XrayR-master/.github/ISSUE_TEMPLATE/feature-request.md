---
name: "功能建议"
about: 给XrayR提出建议，让我们做得更好
title: ''
labels: awaiting reply, feature-request
assignees: ''
---

**描述您想要的功能**

清晰简洁的功能描述。

**描述您考虑过的替代方案** 

是否有任何替代方案可以解决这个问题？ 

**附加上下文** 

在此处添加有关功能请求的任何其他上下文或截图。