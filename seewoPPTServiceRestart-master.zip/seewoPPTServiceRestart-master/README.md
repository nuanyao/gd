# 希沃PPT小工具重启助手

本程序为学校使用希沃一体机的老师们不再受到希沃PPTService异常退出的困扰

## 效果演示

本人使用的是Surface作为程序的开发环境，未在一体机上做过测试。理论上应该是可以成功调用并重启的

![image.png](https://s2.loli.net/2021/12/25/mtL5vejP1IRqzZ3.png)

## 系统要求

因本程序是以Python 3.10.1为基础进行封装使用的，故使用Windows 7的一体机可能无法使用，请见谅！

## 赞助我们

![afdian-MisakaNo.jpg](https://s2.loli.net/2021/12/25/SimocqwhVg89NQJ.jpg)

## 交流群
[Telegram](https://t.me/misakanetcn)
